export default function App() {
  return (
    <main className="min-h-screen bg-blue-50 p-6">
      <header className="bg-blue-900 text-white p-6 rounded-2xl shadow-lg">
        <h1 className="text-4xl font-bold">Dock Docktors</h1>
        <p className="text-lg mt-2">Expert Dock Rebuilding Services</p>
      </header>

      <section className="mt-10 grid md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow">
          <h2 className="text-2xl font-semibold mb-4">About Us</h2>
          <p>
            Dock Docktors is a mobile dock rebuilding service based in North Miami. We specialize in fast, reliable dock repair and reconstruction for waterfront properties. Unlike big companies, we don’t keep you waiting for months—we come to you fast and get the job done.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow">
          <h2 className="text-2xl font-semibold mb-4">Our Services</h2>
          <ul className="list-disc list-inside">
            <li>Dock inspection & damage assessment</li>
            <li>Full dock rebuilding</li>
            <li>Decking replacement</li>
            <li>Piling repair</li>
            <li>Storm damage restoration</li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow md:col-span-2">
          <h2 className="text-2xl font-semibold mb-4">Service Areas</h2>
          <p>
            We service waterfront properties across South Florida including Hollywood, Miami Beach, North Miami, North Miami Beach, Aventura, and Belle Meade. Wherever your dock is—we’ll come to you.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow md:col-span-2">
          <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
          <p className="mb-2">Ready to fix your dock? Get in touch today:</p>
          <p><strong>Email:</strong> contact@dockdocktors.com</p>
          <p><strong>Phone:</strong> (305) 555-DOCK</p>
        </div>
      </section>

      <footer className="text-center text-gray-600 text-sm mt-10">
        &copy; {new Date().getFullYear()} Dock Docktors. All rights reserved.
      </footer>
    </main>
  );
}
